System DVT support software.

This software is expected to be used only for system DVT

Folder structure:

patches:
Patch files to be applied to the tip-sdk before building uboot/kernel/rootfs.
WARNING: Apply patches first and build the uboot, kernel, rootfs before any of the below steps.

install.sh:
- MUST run the script with sudo
- It install dvt pakages, scripts, files from pkgs/ in to lsm_rd.gz file.
- install.sh <directory of lsm_rd.gz> accepts exactly 1 arguments which is path of lsm_rd.gz
  Ex: sudo ./install.sh /home/oc/tip-sdk/out

pkgs:
All DVT related suppport packages

Note: The newly build u-boot has to be flashed on the board to successfully load kernel and rootfs.

DVT testing:

cd dvt/

# python occmd.py help
./occmd.py <module_name> <get/set> <param/all> <value>

Example:

# python occmd.py bb get all


# python occmd.py bb get temperature


# python occmd.py bb set temperature_alert 70000
