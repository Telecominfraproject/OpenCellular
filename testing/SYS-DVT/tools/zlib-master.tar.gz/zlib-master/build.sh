
 export INSTALLDIR=/home/cdot-lap01/ubuntu_16.04/usr/local/Cavium_Networks/OCTEONTX-SDK/linux/cavium-rootfs/tmp-rootfs/usr

 export TARGETMACH=aarch64-thunderx-linux-gnu
 export BUILDMACH=i686-pc-linux-gnu
 export CROSS=aarch64-thunderx-linux-gnu
 export CC=${CROSS}-gcc
 export LD=${CROSS}-ld
 export AS=${CROSS}-as


./configure --prefix=/home/cdot-lap01/ubuntu_16.04/usr/local/Cavium_Networks/OCTEONTX-SDK/linux/cavium-rootfs/tmp-rootfs/usr
make
make install







